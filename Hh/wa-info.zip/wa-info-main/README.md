<img src="https://a.top4top.io/p_2538sd9r20.jpg">

```
apt install git -y
```

```
git clone https://github.com/GH05T-HUNTER5/wa-info
```

```
cd wa-info
```

```
bash setup.sh
```

```
bash wa-info.sh
```

<!--
<img src="https://c.top4top.io/p_2538kk21g0.jpg">
-->

<img src="https://f.top4top.io/p_25388qdkk0.jpg">

```
                                                                                          The use of the wa-info is COMPLETE RESPONSIBILITY of the END-USER. Developers assume NO liability and are NOT responsible for any misuse or damage caused by this program.
```
